from django.apps import AppConfig


class VsphereConfig(AppConfig):
    name = 'vsphere'
