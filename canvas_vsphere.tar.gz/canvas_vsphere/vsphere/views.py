from django.shortcuts import render
from django.http import HttpResponse
from util import vsphereutil

# Create your views here.

def index(request):
	return render(request, 'vsphere/index.html')
#
def show_all_vms(request):
	vminfo_array = vsphereutil.get_all_vms()
	context = {'data':vminfo_array}
	return render(request, 'vsphere/showallvms.html', context)
