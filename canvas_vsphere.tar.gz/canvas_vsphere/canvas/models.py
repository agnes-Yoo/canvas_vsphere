from django.db import models

# vsphere에서 가져온 vm의 정보를 저장하는 table
class VmObject(models.Model):
    name = models.TextField()
    annotation = models.TextField()
    instance_uuid = models.TextField()
    bios_uuid = models.TextField()

# canvas의 사용자와 VmObject와 매핑 될 때마다 생성, vm_id는 VmObject의 id
class UserVm(models.Model):
    account_id = models.IntegerField(default=0)
    course_id = models.IntegerField(default=0)
    user_id = models.IntegerField(default=0)
    user_name = models.CharField(max_length=100)
    vm_id = models.IntegerField(default=0)
