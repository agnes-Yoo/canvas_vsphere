from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.template import Template, Context
from util import canvasutil
import json
import datetime


# Create your views here.

def index(request):
    return render(request, 'canvas/index.html')

def courses(request):
    courses = canvasutil.get_all_courses()
    context = {'data':courses}
    return render(request, 'canvas/courses.html', context)

def users(request, course_id):
    if request.method == "GET":
        print("user with course_id")
        users = canvasutil.get_user_infos_with_course_id(course_id)
        context = {'users' : users}
        return render(request, 'canvas/users.html', context)

def course_vms(request):
    db_entry = CourseVm.objects.filter(id=1)
    print(db_entry)
    return 1
