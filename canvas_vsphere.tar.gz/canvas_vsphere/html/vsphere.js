function showVmConsoleWindow(){
        pathname = document.referrer
        courseId = pathname.split("courses/")[1].split("/")[0]
        url = "/VM/vmConsole/" + courseId
	href.location = url
}
