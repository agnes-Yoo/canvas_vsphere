import psycopg2
from psycopg2.extras import RealDictCursor, execute_batch
import requests
import urllib3
from canvas_vsphere import settings
import json

#logging
import logging
logger = logging.getLogger('default')

def get_all_courses_students():
    try:
        canvas_connection = psycopg2.connect(host=settings.CANVAS_HOST, dbname=settings.CANVAS_DATABASE_NAME, user=settings.CANVAS_USERNAME, password=settings.CANVAS_PASSWORD)
        canvas_cursor = canvas_connection.cursor(cursor_factory=RealDictCursor)
        query_string = "select * from courses where workflow_state = 'available'"
        canvas_cursor.execute(query_string)
        result = canvas_cursor.fetchall()

        course_list = []
        course_ids = []
        for course in result:
            course_list.append(course)
            course_ids.append(course['id'])

        user_ids = []
        user_ids_in_course = {}

        for course_id in course_ids:
            user_ids = []
            query_string = "select * from enrollments where workflow_state = 'active' and course_id=" + str(course_id)
            canvas_cursor.execute(query_string)
            enrollments = canvas_cursor.fetchall()
            for enrollment in enrollments:
                user_ids.append(enrollment['user_id'])
            user_ids_in_course[course_id] = user_ids

        return user_ids_in_courses
    except psycopg2.Error as error:
        logger.error('in canvasutil.get_all_courses_students(), ' + error.pgerror) 
        print(error.pgerror)

def get_user_infos_with_course_id(course_id):
    try:
        canvas_connection = psycopg2.connect(host=settings.CANVAS_HOST, dbname=settings.CANVAS_DATABASE_NAME, user=settings.CANVAS_USERNAME, password=settings.CANVAS_PASSWORD)
        canvas_cursor = canvas_connection.cursor(cursor_factory=RealDictCursor)
        query_string = "select * from enrollments where workflow_state = 'active' and type != 'StudentViewEnrollment' and course_id=$1;"
        prepared_query_string = "prepare getenrollment(int) as " + query_string
        canvas_cursor.execute(prepared_query_string)
        execute_batch(canvas_cursor, "execute getenrollment(%s)", [(course_id, )])
        enrollments = canvas_cursor.fetchall()

        user_ids = []

        for enrollment in enrollments:
            user_ids.append(enrollment["user_id"])

        #query_string = 'select * from users where id=$1;'
        query_string = "select * from users where id=$1 and workflow_state != 'deleted';"
        prepared_query_string = "prepare getusers(int) as " + query_string
        canvas_cursor.execute(prepared_query_string)

        users = []
        for user_id in user_ids:
            execute_batch(canvas_cursor, "execute getusers(%s)", [(user_id,)])
            user = canvas_cursor.fetchone()
            users.append(user)

        user_sorted = sorted(users, key=lambda k:k['name'])

        #return users
        return user_sorted

    except psycopg2.Error as error:
        logger.error('in canvasutil.get_user_infos_with_course_id(), ' + error.pgerror)
        print(error.pgerror)

def get_all_courses():
    try:
        canvas_connection = psycopg2.connect(host=settings.CANVAS_HOST, dbname=settings.CANVAS_DATABASE_NAME, user=settings.CANVAS_USERNAME, password=settings.CANVAS_PASSWORD)
        canvas_cursor = canvas_connection.cursor(cursor_factory=RealDictCursor)
        query_string = "select * from courses where workflow_state = 'available'"
        canvas_cursor.execute(query_string)
        result = canvas_cursor.fetchall()

        course_list = []
        course_ids = []
        for course in result:
            course_list.append(course)
            course_ids.append(course['id'])

        return course_list
    except psycopg2.Error as error:
        logger.error('in canvasutil.get_all_courses(), ' + error.pgerror)
        print(error.pgerror)
        return -1


def get_user(user_id):
    try:
        canvas_connection = psycopg2.connect(host=settings.CANVAS_HOST, dbname=settings.CANVAS_DATABASE_NAME, user=settings.CANVAS_USERNAME, password=settings.CANVAS_PASSWORD)
        canvas_cursor = canvas_connection.cursor(cursor_factory=RealDictCursor)
        #query_string = "select * from users where id=$1;"
        query_string = "select * from users where id=$1 and workflow_state != 'deleted';"
        prepared_query_string = "prepare getuser(int) as " + query_string
        canvas_cursor.execute(prepared_query_string)
        execute_batch(canvas_cursor, "execute getuser(%s)", [(user_id, )])
        user = canvas_cursor.fetchall()
        if len(user) != 0:
            return user[0]
        else:
            return -1

    except psycopg2.Error as error:
        logger.error('in canvasutil.get_user(), ' + error.pgerror)
        print(error.pgerror)
        return -1


# 로그인 정보가 없으면 False, 로그인 정보가 있으면 로그인한 사용자의 정보 반환
def canvas_check_login(request):
    urllib3.disable_warnings()

    _csrf_token = request.COOKIES.get("_csrf_token")
    _normandy_session = request.COOKIES.get("_normandy_session")
    log_session_id = request.COOKIES.get("log_session_id")

    context = {}
    url = ''

    if _csrf_token == None or _normandy_session == None or log_session_id == None:
        logger.error('in canvasutil.canvas_check_login(), Canvas LMS 로그인 정보를 확인할 수 없습니다.')
        return False
    else:
        url = "https://" + settings.CANVAS_HOST + "/api/v1/users/self"
        cookies = {
            "_csrf_token" : _csrf_token,
            "_normandy_session" : _normandy_session,
            "log_session_id" : log_session_id,
        }
        response = requests.get(url, verify=False, cookies=cookies)
        if response.status_code == 200:
            context = {'message' : '로그인 정보를 확인했습니다.', 'userinfo' : response.text.split(';')[-1]}
            return context
        else:
            return False


#로그인 정보가 없거나 조회가 불가능한 경우 False 반환, 관리자가 조회할 경우 True 반환
def check_account_admin(request, account_id):
    urllib3.disable_warnings()

    _csrf_token = request.COOKIES.get("_csrf_token")
    _normandy_session = request.COOKIES.get("_normandy_session")
    log_session_id = request.COOKIES.get("log_session_id")
    context = {}
    url = ''
    if _csrf_token == None or _normandy_session == None or log_session_id == None:
        logger.error('in canvasutil.check_account_admin(), Canvas LMS 로그인 정보를 확인할 수 없습니다.')
        return False
    else:
        url = "https://" + settings.CANVAS_HOST + "/api/v1/accounts/" + str(account_id) + "/admins"
        cookies = {
            "_csrf_token" : _csrf_token,
            "_normandy_session" : _normandy_session,
            "log_session_id" : log_session_id,
        }
        response = requests.get(url, verify=False, cookies=cookies)
        if response.status_code == 200:
            return True
        else:
            logger.error('in canvasuti.check_account_admin(), Canvas LMS Admin 로그인 정보를 확인할 수 없습니다.')
            return False

def get_root_account_with_course(course_id):
    try:
        canvas_connection = psycopg2.connect(host=settings.CANVAS_HOST, dbname=settings.CANVAS_DATABASE_NAME, user=settings.CANVAS_USERNAME, password=settings.CANVAS_PASSWORD)
        canvas_cursor = canvas_connection.cursor(cursor_factory=RealDictCursor)
        query_string = "select * from courses where id=$1;"
        prepared_query_string = "prepare getcourse(int) as " + query_string
        canvas_cursor.execute(prepared_query_string)
        execute_batch(canvas_cursor, "execute getcourse(%s)", [(course_id, )])
        course = canvas_cursor.fetchone()
        account_id = course['root_account_id']

        query_string = 'select * from accounts where id=$1;'
        prepared_query_string = "prepare getrootaccount(int) as " + query_string
        canvas_cursor.execute(prepared_query_string)
        execute_batch(canvas_cursor, "execute getrootaccount(%s)", [(account_id,)])
        account = canvas_cursor.fetchone()

        return account

    except psycopg2.Error as error:
        logger.error('in canvasutil.get_root_account_with_course(), ' + error.pgerror)
        print(error.pgerror)

def get_account_with_course(course_id):
    try:
        canvas_connection = psycopg2.connect(host=settings.CANVAS_HOST, dbname=settings.CANVAS_DATABASE_NAME, user=settings.CANVAS_USERNAME, password=settings.CANVAS_PASSWORD)
        canvas_cursor = canvas_connection.cursor(cursor_factory=RealDictCursor)
        query_string = "select * from courses where id=$1;"
        prepared_query_string = "prepare getcourse(int) as " + query_string
        canvas_cursor.execute(prepared_query_string)
        execute_batch(canvas_cursor, "execute getcourse(%s)", [(course_id, )])
        course = canvas_cursor.fetchone()
        account_id = course['account_id']

        query_string = 'select * from accounts where id=$1;'
        prepared_query_string = "prepare getaccount(int) as " + query_string
        canvas_cursor.execute(prepared_query_string)
        execute_batch(canvas_cursor, "execute getaccount(%s)", [(account_id,)])
        account = canvas_cursor.fetchone()

        return account

    except psycopg2.Error as error:
        logger.error('in canvasutil.get_account_with_course(), ' + error.pgerror)
        print(error.pgerror)
        return None


# 로그인한 사용자가 Account의 관리자 권한을 하나라도 가지고 있을 경우 True, 관리자 권한이 없는 경우 False 반환
def canvas_check_adminable_accounts(request):
    urllib3.disable_warnings()

    _csrf_token = request.COOKIES.get("_csrf_token")
    _normandy_session = request.COOKIES.get("_normandy_session")
    log_session_id = request.COOKIES.get("log_session_id")

    context = {}
    url = ''

    if _csrf_token == None or _normandy_session == None or log_session_id == None:
        return False
    else:
        url = "https://" + settings.CANVAS_HOST + "/api/v1/users/self"
        cookies = {
            "_csrf_token" : _csrf_token,
            "_normandy_session" : _normandy_session,
            "log_session_id" : log_session_id,
        }
        response = requests.get(url, verify=False, cookies=cookies)
        if response.status_code == 200:
            userinfo = json.loads(response.text.split(';')[-1])
            try:
                canvas_connection = psycopg2.connect(host=settings.CANVAS_HOST, dbname=settings.CANVAS_DATABASE_NAME, user=settings.CANVAS_USERNAME, password=settings.CANVAS_PASSWORD)
                canvas_cursor = canvas_connection.cursor(cursor_factory=RealDictCursor)
                query_string = "SELECT * FROM accounts INNER JOIN account_users ON account_id = accounts.id\
                                WHERE (accounts.workflow_state<>'deleted')\
                                AND account_users.user_id = $1\
                                AND (account_users.workflow_state != 'deleted');"
                prepared_query_string = "prepare adminable_accounts(int) as " + query_string
                canvas_cursor.execute(prepared_query_string)
                execute_batch(canvas_cursor, "execute adminable_accounts(%s)", [(userinfo['id'], )])
                adminables = canvas_cursor.fetchall()

                if len(adminables) == 0:
                    logger.error('in canvasutil.canvas_check_adminable_accounts(), adminable 정보를 확인할 수 없습니다.')
                    return False
                else:
                    return True

            except psycopg2.Error as error:
                logger.error('in canvasutil.canvas_check_adminable_accounts(), ' + error.pgerror)
                print(error.pgerror)
        else:
            logger.error('in canvasutil.canvas_check_adminable_accounts(), Canvas LMS 로그인 정보를 확인할 수 없습니다.')
            return False
