import atexit
import argparse
import getpass
import ssl
import json
import time

from pyVim import connect
from pyVmomi import vmodl
from pyVmomi import vim

from . import cli
from . import tasks
from canvas_vsphere import settings
import datetime


#logging
import logging
logger = logging.getLogger('default')

ssl_context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
ssl_context.verify_mode = ssl.CERT_NONE

def vminfo_to_json(virtual_machine):
    result = []
    summary = virtual_machine.summary
    data = {
        "name" : summary.config.name,
        # "datastore" : virtual_machine.datastore.info,
        "instance_uuid" : summary.config.instanceUuid,
        "bios_uuid" : summary.config.uuid,
        "annotation" : summary.config.annotation,
        "state" : summary.runtime.powerState,
        "ip" : summary.guest.ipAddress,
    }
    return data

def get_all_vms():
    try:
        service_instance = connect.SmartConnect(host=settings.VSPHERE_HOST, user=settings.VSPHERE_USER, pwd=settings.VSPHERE_PASSWORD, sslContext=ssl_context)
        atexit.register(connect.Disconnect, service_instance)
        content = service_instance.RetrieveContent()
        container = content.rootFolder
        view_type = [vim.VirtualMachine]
        recursive = True
        container_view = content.viewManager.CreateContainerView(container, view_type, recursive)

        children = container_view.view

        vminfo_array = []
        for child in children:
            if child.summary.config.name.startswith(settings.VSPHERE_PREPIX):
                vminfo_array.append(vminfo_to_json(child))

        return vminfo_array

    except vmodl.MethodFault as error:
        logger.error('in vsphereutil.get_all_vms(), ' + error.msg)
        print(("Caught vmodl fault : " + error.msg))
        return -1

def generate_vmrc_console(vm_name):
    try:
        service_instance = connect.SmartConnect(host=settings.VSPHERE_HOST, user=settings.VSPHERE_USER, pwd=settings.VSPHERE_PASSWORD, sslContext=ssl_context)
        atexit.register(connect.Disconnect, service_instance)
        content = service_instance.RetrieveContent()
        container = content.rootFolder
        view_type = [vim.VirtualMachine]
        recursive = True
        container_view = content.viewManager.CreateContainerView(container, view_type, recursive)

        for c in container_view.view:
            if c.name == vm_name:
                vm = c
                break

        vm_moid = vm._moId

        vcenter_data = content.setting
        vcenter_settings = vcenter_data.setting
        console_port = '443'
        session_manager = content.sessionManager
        session = session_manager.AcquireCloneTicket()

        vmrc_uri = "vmrc://clone:" + session + "@" + settings.VSPHERE_HOST + ":" + console_port + "/?moid=" + str(vm_moid)
        return vmrc_uri
        sleep(60)

    except vmodl.MethodFault as error:
        logger.error('in vsphereutil.generate_vmrc_console(), ' + error.msg)
        print(("Caught vmodl fault : " + error.msg))
        return -1

def take_snapshot(bios_uuid):
    try:
        service_instance = connect.SmartConnect(host=settings.VSPHERE_HOST, user=settings.VSPHERE_USER, pwd=settings.VSPHERE_PASSWORD, sslContext=ssl_context)
        vm = service_instance.content.searchIndex.FindByUuid(None, bios_uuid, True, False)

        if vm is None:
            print("vm not found")
            return False

        now = datetime.datetime.now()
        snapshot_name = str(vm.name) + "_" + str(now.year) + str(now.month) + str(now.day) + str(now.hour) + str(now.minute) + str(now.second)
        print(snapshot_name)

        vm.CreateSnapshot_Task(name=snapshot_name, description="", memory=True, quiesce=False)
        return True

    except vmodl.MethodFault as error:
        logger.error('in vsphereutil.take_snapshot(), ' + error.msg)
        print(("Caught vmodl fault : " + error.msg))

def revert_snapshot(bios_uuid):
    try:
        service_instance = connect.SmartConnect(host=settings.VSPHERE_HOST, user=settings.VSPHERE_USER, pwd=settings.VSPHERE_PASSWORD, sslContext=ssl_context)
        vm = service_instance.content.searchIndex.FindByUuid(None, bios_uuid, True, False)

        if vm is None:
            print("vm not found")
            return False

        if vm.snapshot is None:
            print("vm snapshot not found")
            return False
        else:
            vm_snapshot = vm.snapshot.currentSnapshot
            vm_snapshot.RevertToSnapshot_Task()
        return True

    except vmodl.MethodFault as error:
        logger.error('in vsphereutil.revert_snapshot(), ' + error.msg)
        print(("Caught vmodl fault : " + error.msg))

def get_vm_status(vm_name):
#def get_vm_status():
    try:
        service_instance = connect.SmartConnect(host=settings.VSPHERE_HOST, user=settings.VSPHERE_USER, pwd=settings.VSPHERE_PASSWORD, sslContext=ssl_context)
        atexit.register(connect.Disconnect, service_instance)
        content = service_instance.RetrieveContent()
        container = content.rootFolder
        view_type = [vim.VirtualMachine]
        recursive = True
        container_view = content.viewManager.CreateContainerView(container, view_type, recursive)
    
        #vminfo_array = []
        #for child in children:
        #    if child.summary.config.name.startswith(settings.VSPHERE_PREPIX):
        #        vminfo_array.append(vminfo_to_json(child))
        #
        #return vminfo_array
        vm = ''
        for c in container_view.view:
            if c.name == vm_name:
                vm = c
                break
        vminfo = vminfo_to_json(vm)

        return vminfo['state']
    except vmodl.MethodFault as error:
        logger.error('in vsphereutil.get_vm_status(), ' + error.msg)
        print(("Caught vmodl fault : " + error.msg))


#VM 전원 On 또는 Off 하는 함수
def vm_power_on_off(bios_uuid, option):
    try:
        service_instance = connect.SmartConnect(host=settings.VSPHERE_HOST, user=settings.VSPHERE_USER, pwd=settings.VSPHERE_PASSWORD, sslContext=ssl_context)
        vm = service_instance.content.searchIndex.FindByUuid(None, bios_uuid, True, False)
        
        if vm is None:
            print("vm not found")
            return False
        else:
            if option == "poweron":
                task = vm.PowerOnVM_Task()
            elif option == "poweroff":
                task = vm.PowerOffVM_Task()
            else:
                print("option not defined")
                return False

            tasks.wait_for_tasks(service_instance, [task])
            return True
    except vmodl.MethodFault as error:
        logger.error('in vsphereutil.vm_power_on_off(), ' + error.msg)
        print(("Caught vmodl fault : " + error.msg))


# dictionary 형태의 인자 전달 필요, instance_uuid와 bios_uuid를 비교한 결과 반환
def vmobject_dict_equal(first_vm_object, second_vm_object):
    if first_vm_object['instance_uuid'] == second_vm_object['instance_uuid']:
        if first_vm_object['bios_uuid'] == second_vm_object['bios_uuid']:
            return True
        else:
            return False
    else:
        return False

def vmobject_dict_name_equal(first_vm_object, second_vm_object):
    if first_vm_object['name'] == second_vm_object['name']:
        return True
    else:
        return False

