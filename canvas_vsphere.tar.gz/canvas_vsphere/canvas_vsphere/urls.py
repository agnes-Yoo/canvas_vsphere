"""canvas_vsphere URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
# from django.contrib import admin
from django.urls import include, path
from django.views.generic.base import RedirectView
from django.conf.urls import url
from django.conf import settings

import canvas_vsphere.views
import vsphere.views
import canvas.views

urlpatterns = [
    url('^$', canvas_vsphere.views.index),
    url('manageVM/$', canvas_vsphere.views.manage_vm),
    url('connectOrDisconnectVM', canvas_vsphere.views.connect_or_disconnect_vm),
    url('initVM', canvas_vsphere.views.init_vm_db),
    url('updateVM', canvas_vsphere.views.update_vm_db),
    url('searchVM', canvas_vsphere.views.search_vm),
    url('getAllVM', canvas_vsphere.views.get_all_vm),
    url('getUserVM', canvas_vsphere.views.get_user_vm),
    url('manageUserVM/(?P<user_id>[0-9]{1,4})', canvas_vsphere.views.manage_user_vm),
    url('vmConsole/$', canvas_vsphere.views.vm_console),
    url('vmConsole/(?P<course_id>[0-9]{1,4})', canvas_vsphere.views.vm_console),
    url('takeSnapshotVM', canvas_vsphere.views.take_snapshot_vm),
    url('revokeVM', canvas_vsphere.views.revoke_vm),
    url('getVmPowerState', canvas_vsphere.views.get_vm_power_state),
    url('powerOnOffVM', canvas_vsphere.views.power_on_off_vm),

    url('vsphere/$', vsphere.views.index),
    url('vsphere/showallvms/', vsphere.views.show_all_vms),

    url('canvas/$', canvas.views.index),
    #url('canvas/courses/$', canvas.views.courses),
    #url('canvas/courses/users/$', canvas.views.courses),
    #path('canvas/courses/<int:course_id>/users/', canvas.views.users, name="users"),
    url('canvas/courses/(?P<course_id>[0-9]{1,6})', canvas.views.users),
    url('searchVm', canvas_vsphere.views.search_vm),
]
