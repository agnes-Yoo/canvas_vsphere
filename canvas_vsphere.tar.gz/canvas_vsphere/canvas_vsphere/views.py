from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from util import canvasutil, vsphereutil
from canvas.models import VmObject, UserVm
from django.forms.models import model_to_dict
import json

#logging
import logging
logger = logging.getLogger('default')

def parameter_string_to_list(string_value):
    return_value = []
    temp = string_value.split(',')
    for value in temp:
        return_value.append(int(value))

    return return_value

def index(request):
    return render(request, 'canvas_vsphere/index.html')

def manage_vm(request):
    if request.method == "GET":
        result = canvasutil.canvas_check_login(request)
        #result = True
        if result == False:
            logger.info('in manage_vm, login information not found')
            context = {'message' : '로그인 정보가 없습니다.'}
            return render(request, 'error/error.html', context)
        else:
            logger.info('in manage_vm, get login information success')
            adminable = canvasutil.canvas_check_adminable_accounts(request)
            #adminable = True
            if adminable == True:
                userinfo = json.loads(result['userinfo'])
                courses = canvasutil.get_all_courses()
                vms = []
                uservms = []
                vmmodels = VmObject.objects.all()
                uservmmodels = UserVm.objects.all()
                for uservm in uservmmodels:
                    uservms.append(model_to_dict(uservm))
               
                for vm in vmmodels:
                    vms.append(model_to_dict(vm))

                for vm in vms:
                    vm.update({'is_use':'false'})
                #    vm.update({'power_state':vsphereutil.get_vm_status(vm['name'])})

                #이미 할당된 vm 표시하기
                for vm in vms:
                    for uservm in uservms:
                        if vm['id'] == uservm['vm_id']:
                            vm.update({'is_use':'true'})

                context = {'courses' : courses, 'vms' : vms}
                return render(request, 'canvas_vsphere/manageVM.html', context)
            else:
                logger.info('in manage_vm, adminable not found')
                context = {'message' : '관리자로 로그인 해주세요'}
                return render(request, 'error/error.html', context)

    elif request.method == "POST":
        print("connect vm with post method")

def connect_or_disconnect_vm(request):
    if request.method == "POST":
        result = canvasutil.canvas_check_login(request)
        if result == False:
            context = {'message' : '로그인 정보가 없습니다.'}
            return JsonResponse(context, status="401")
        else:
            adminable = canvasutil.canvas_check_adminable_accounts(request)
            if adminable == True:
                course_id = request.POST.get("course_id")
                user_ids = parameter_string_to_list(request.POST.get("user_ids"))
                vm_ids = parameter_string_to_list(request.POST.get("vm_ids"))
                option = request.POST.get("option")
                account = canvasutil.get_account_with_course(course_id)
                result = ''
                userinfos = []
                for user_id in user_ids:
                    userinfos.append(canvasutil.get_user(user_id))

                if option == "connect":
                    for userinfo in userinfos:
                        for vm_id in vm_ids:
                            result = UserVm.objects.filter(user_id=userinfo['id'], course_id=course_id, account_id=account['id'], vm_id=vm_id)
                            if len(result) == 0:
                                UserVm(user_id=userinfo['id'], course_id=course_id, account_id=account['id'], user_name=userinfo['name'], vm_id=vm_id).save()
                elif option == "disconnect":
                    for userinfo in userinfos:
                        for vm_id in vm_ids:
                            UserVm.objects.filter(user_id=userinfo['id'], course_id=course_id, account_id=account['id'], vm_id=vm_id).delete()
                else:
                    context = {'message' : '잘못된 옵션이 존재합니다.'}
                    return JsonResponse(context, status=401)
                context = {'message' : '연결 / 해제가 완료되었습니다.'}
                return JsonResponse(context)
            else:
                context = {'message' : '관리자로 로그인 해주세요'}
                return JsonResponse(context, status="401")

def init_vm_db(request):
    if request.method == "POST":
        VmObject.objects.all().delete()
        UserVm.objects.all().delete()
        vminfo_array = vsphereutil.get_all_vms()
        for vm in vminfo_array:
            VmObject(name=vm["name"], instance_uuid=vm["instance_uuid"], bios_uuid=vm["bios_uuid"], annotation=vm["annotation"]).save()

    context = {'message':'init vm info success'}
    return JsonResponse(context)

def update_vm_db(request):
    if request.method == "POST":
        result = VmObject.objects.all()
        vmobjects = []
        for vm in result:
            vmobjects.append(model_to_dict(vm))

        vminfos = vsphereutil.get_all_vms()

        count = len(vmobjects)
        is_match = False

        for vminfo in vminfos:
            index = 0
            for vmobject in vmobjects:
                if vsphereutil.vmobject_dict_equal(vminfo, vmobject) == True:
                    is_match = True
                    if vsphereutil.vmobject_dict_name_equal(vminfo, vmobject) == True:
                        break
                    else:
                        VmObject.objects.filter(name=vmobject['name']).update(name=vminfo['name'])
                        break
            if is_match == False:
                VmObject(name=vminfo["name"], instance_uuid=vminfo["instance_uuid"], bios_uuid=vminfo["bios_uuid"], annotation=vminfo["annotation"]).save()
            is_match = False

    context = {'message' : '데이터베이스 업데이트 완료'}
    return JsonResponse(context)

def search_vm(request):
    if request.method == "POST":
        result = canvasutil.canvas_check_login(request)
        if result == False:
            context = {'message' : '로그인 정보가 없습니다.'}
            return JsonResponse(context, status=404)
        else:
            search_string = request.POST.get("vmname")
            result = VmObject.objects.filter(name__contains=search_string, is_mapped=False)
            if len(result) == 0:
                context = {'message' : '연결할 수 있는 VM이 없습니다.'}
                return JsonResponse(context, status=404)
            else:
                context = {'vms' : result}
                return render(request, "vsphere/showallvms.html", context)

def get_all_vm(request):
    if request.method == "POST":
        result = canvasutil.canvas_check_login(request)
        if result == False:
            logger.info('in get_all_vm, login information not found')
            context = {'message' : '로그인 정보가 없습니다.'}
            return JsonResponse(context, status=404)
        else:
            vms = []
            uservms = []
            vmmodels = VmObject.objects.all()
            uservmmodels = UserVm.objects.all()

            for uservm in uservmmodels:
                uservms.append(model_to_dict(uservm))

            for vm in vmmodels:
                vms.append(model_to_dict(vm))

            for vm in vms:
                vm.update({'is_use':'false'})
                #vm.update({'power_state':vsphereutil.get_vm_status(vm['name'])})

            for vm in vms:
                for uservm in uservms:
                    if vm['id'] == uservm['vm_id']:
                        vm.update({'is_use':'true'})

            context = {'vms' : vms}
            return render(request, "vsphere/showallvms.html", context)

            #print(result)
            #context = {'vms' : result}
            #return render(request, "vsphere/showallvms.html", context)

def get_user_vm(request):
    if request.method == "POST":
        result = canvasutil.canvas_check_login(request)
        if result == False:
            context = {'message' : '로그인 정보가 없습니다.'}
            return JsonResponse(context, status=404)
        else:
            user_id = request.POST.get('user_id')
            course_id = request.POST.get('course_id')
            if len(user_id) != 0:
                uservms = UserVm.objects.filter(user_id=user_id, course_id=course_id)
                if len(uservms) == 0:
                    context = {'message' : '해당 사용자에 할당된 자원이 없습니다.'}
                    return JsonResponse(context, status=404)
                else:
                    vms = []
                    for uservm in uservms:
                        vms.append(VmObject.objects.filter(id=uservm.vm_id).first())
                    context = {'vms' : vms}
                    return render(request, "vsphere/showuservms.html", context)
            else:
                context = {'message' : '사용자가 선택되지 않았습니다.'}
                return JsonResponse(context, status=0)

def manage_user_vm(request):
    if request.method == "GET":
        result = canvasutil.canvas_check_login(request)
        if result == False:
            context = {'message' : '로그인 정보가 없습니다.'}
            return render(request, 'error/error.html', context)
        else:
            adminable = canvasutil.canvas_check_adminable_accounts(request)
            if adminable == True:
                userinfo = json.loads(result['userinfo'])

                courses = canvasutil.get_all_courses()
                vms = []
                vmmodels = VmObject.objects.all()
                for vm in vmmodels:
                    vms.append(model_to_dict(vm))

                context = {'courses' : courses, 'vms' : vms}
                return render(request, 'canvas_vsphere/manageVM.html', context)
            else:
                context = {'message' : '관리자로 로그인 해주세요'}
                return render(request, 'error/error.html', context)

        context = {'message' : 'message test'}
        return JsonResponse(context)

def vm_console(request, course_id):
    if request.method == "GET":
        result = canvasutil.canvas_check_login(request)
        if result == False:
            context = {'message' : '로그인 정보가 없습니다.'}
            return render(request, "error/error.html", context, status=401)
        else:
            userinfo = json.loads(result['userinfo'])
            user_id = userinfo['id']
            user_vm_list = UserVm.objects.filter(course_id=course_id, user_id=user_id)

            vm_list = []
            for user_vm in user_vm_list:
                vm_object = VmObject.objects.filter(id=user_vm.vm_id).first()
                if vm_object is None:
                    break
                else:
                    vm_list.append(vm_object)

            if len(vm_list) != 0:
                #print(vm_list)
                context = {'vms' : vm_list}
                return render(request, "canvas_vsphere/vmConsoleList.html", context)
            else:
                context = {'message':'해당 과목에서 사용할 수 있는 VM이 없습니다.'}
                return render(request, "error/error.html", context, status=404)
    elif request.method == "POST":
        vm_name = request.POST.get("vmname")
        url = vsphereutil.generate_vmrc_console(vm_name)
        context = {'url':url}
        return JsonResponse(context)

def take_snapshot_vm(request):
    print("take snapshot vm")
    if request.method == "POST":
        result = canvasutil.canvas_check_login(request)
        if result == False:
            context = {'message' : '로그인 정보가 없습니다.'}
            return render(request, 'error/error.html', context)
        else:
            adminable = canvasutil.canvas_check_adminable_accounts(request)
            print(adminable)
            if adminable == True:
                vm_id = request.POST.get("vm_id")
                vm_object = VmObject.objects.filter(id=vm_id)
                if len(vm_object) == 0:
                    context = {"message" : "VM 정보를 확인할 수 없습니다."}
                    return render(request, "error/error.html", context, status=404)
                else:
                    result = vsphereutil.take_snapshot(model_to_dict(vm_object[0])['bios_uuid'])
                    if result == True:
                        context = {"message" : "VM 스냅샷 되돌리기에 성공했습니다."}
                        return JsonResponse(context)
                    else:
                        context = {"message" : "VM 스냅샷 되돌리기가 실패했습니다."}
                        return JsonResponse(context)
            else:
                context = {'message' : '관리자로 로그인 해주세요'}
                return render(request, 'error/error.html', context)


def revoke_vm(request):
    if request.method == "POST":
        result = canvasutil.canvas_check_login(request)
        if result == False:
            context = {'message' : '로그인 정보가 없습니다.'}
            return render(request, 'error/error.html', context)
        else:
            #adminable = canvasutil.canvas_check_adminable_accounts(request)
            adminable = True
            if adminable == True:
                print('adminable true')
                vm_id = request.POST.get("vm_id")
                vm_object = ''
                vm_object = VmObject.objects.filter(id=vm_id)
                if len(vm_object) == 0:
                    context = {"message" : "VM 정보를 확인할 수 없습니다."}
                    return render(request, "error/error.html", context, status=404)
                else:
                    print(model_to_dict(vm_object[0]))
                    result = vsphereutil.revert_snapshot(model_to_dict(vm_object[0])['bios_uuid'])
                    if result == True:
                        context = {"message" : "VM 스냅샷 되돌리기에 성공했습니다."}
                        return JsonResponse(context)
                    else:
                        context = {"message" : "VM 스냅샷 되돌리기가 실패했습니다."}
                        return JsonResponse(context, status=500)
            else:
                context = {'message' : '관리자로 로그인 해주세요'}
                return render(request, 'error/error.html', context)

def get_vm_power_state(request):
    if request.method == "POST":
        result = canvasutil.canvas_check_login(request)
        if result == False:
            context = {'message' : '로그인 정보가 없습니다.'}
            return JsonResponse(context)
        else:
            adminable = canvasutil.canvas_check_adminable_accounts(request)
            if adminable == True:
                vm_name = request.POST.get("vm_name")
                vm_state = vsphereutil.get_vm_status(vm_name)
                #vminfo_array = vsphereutil.get_vm_status()

                #vm_state = ''

                #for vm in vminfo_array:
                #    if vm_name == vm['name']:
                #        vm_state = vm['state']

                context = {'state' : vm_state}
                return JsonResponse(context)
            else:
                context = {'message' : '관리자로 로그인 해주세요'}
                return JsonResponse(context, status=403)

def power_on_off_vm(request):
    if request.method == "POST":
        result = canvasutil.canvas_check_login(request)
        if result == False:
            context = {'message' : '로그인 정보가 없습니다.'}
            return JsonResponse(context, status="401")
        else:
            adminable = canvasutil.canvas_check_adminable_accounts(request)
            if adminable == True:
                bios_uuid = request.POST.get("bios_uuid")
                option = request.POST.get("option")
                result = vsphereutil.vm_power_on_off(bios_uuid, option)

                if result == True:
                    context = {'message' : '전원 ' + option.upper() + ' 성공'}
                else:
                    context = {'message' : '전원 ' + option.upper() + ' 실패'}
                return JsonResponse(context)
            else:
                context = {'message' : '관리자로 로그인 해주세요'}
                return render(request, 'error/error.html', context)

def search_vm(request):
    if request.method == "POST":
        result = canvasutil.canvas_check_login(request)
        if result == False:
            context = {'message' : '로그인 정보가 없습니다.'}
            return JsonResponse(context, status='401')
        else:
            adminable = canvasutil.canvas_check_adminable_accounts(request)
            if adminable == True:
                keyword = request.POST.get("keyword")
                vms = []
                uservms = []
                vmmodels = VmObject.objects.filter(name__contains=keyword)
                uservmmodels = UserVm.objects.all()

                for uservm in uservmmodels:
                    uservms.append(model_to_dict(uservm))

                for vm in vmmodels:
                    vms.append(model_to_dict(vm))

                for vm in vms:
                    vm.update({'is_use':'false'})
                
                for vm in vms:
                    for uservm in uservms:
                        if vm['id'] == uservm['vm_id']:
                            vm.update({'is_use':'true'})

                context = {'vms':vms}
                return render(request, "vsphere/showallvms.html", context)
            else:
                context = {'message':'관리자로 로그인 해주세요'}
                return render(request, 'error/error.html', context)
